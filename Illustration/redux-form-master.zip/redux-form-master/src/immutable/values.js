// @flow
import createValues from '../createValues'
import immutable from '../structure/immutable'

export default createValues(immutable)
