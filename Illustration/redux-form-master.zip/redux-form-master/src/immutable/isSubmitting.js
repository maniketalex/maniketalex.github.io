// @flow
import createIsSubmitting from '../selectors/isSubmitting'
import immutable from '../structure/immutable'

export default createIsSubmitting(immutable)
