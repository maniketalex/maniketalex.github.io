// @flow
import createGetFormNames from '../selectors/getFormNames'
import immutable from '../structure/immutable'

export default createGetFormNames(immutable)
