// @flow
import createIsValid from '../selectors/isValid'
import immutable from '../structure/immutable'

export default createIsValid(immutable)
