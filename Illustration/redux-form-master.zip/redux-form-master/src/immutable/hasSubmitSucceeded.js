// @flow
import createHasSubmitSucceeded from '../selectors/hasSubmitSucceeded'
import immutable from '../structure/immutable'

export default createHasSubmitSucceeded(immutable)
