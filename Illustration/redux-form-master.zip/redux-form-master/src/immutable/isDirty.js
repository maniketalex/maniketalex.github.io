// @flow
import createIsDirty from '../selectors/isDirty'
import immutable from '../structure/immutable'

export default createIsDirty(immutable)
