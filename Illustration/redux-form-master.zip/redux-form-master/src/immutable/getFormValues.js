// @flow
import createGetFormValues from '../selectors/getFormValues'
import immutable from '../structure/immutable'

export default createGetFormValues(immutable)
