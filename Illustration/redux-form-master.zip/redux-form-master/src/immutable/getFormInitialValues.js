// @flow
import createGetFormInitialValues from '../selectors/getFormInitialValues'
import immutable from '../structure/immutable'

export default createGetFormInitialValues(immutable)
