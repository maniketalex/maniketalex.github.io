// @flow
import createIsAsyncValidating from '../selectors/isAsyncValidating'
import immutable from '../structure/immutable'

export default createIsAsyncValidating(immutable)
