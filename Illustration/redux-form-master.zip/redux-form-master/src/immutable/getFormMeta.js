// @flow
import createGetFormMeta from '../selectors/getFormMeta'
import immutable from '../structure/immutable'

export default createGetFormMeta(immutable)
