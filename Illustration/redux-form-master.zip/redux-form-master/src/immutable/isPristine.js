// @flow
import createIsPristine from '../selectors/isPristine'
import immutable from '../structure/immutable'

export default createIsPristine(immutable)
