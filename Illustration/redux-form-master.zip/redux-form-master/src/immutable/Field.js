// @flow
import createField from '../createField'
import immutable from '../structure/immutable'

export default createField(immutable)
