// @flow
import createFormValues from '../createFormValues'
import immutable from '../structure/immutable'

export default createFormValues(immutable)
