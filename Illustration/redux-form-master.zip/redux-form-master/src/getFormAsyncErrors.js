// @flow
import createGetFormAsyncErrors from './selectors/getFormAsyncErrors'
import plain from './structure/plain'

export default createGetFormAsyncErrors(plain)
