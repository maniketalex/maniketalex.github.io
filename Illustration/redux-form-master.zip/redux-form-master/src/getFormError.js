// @flow
import createGetFormError from './selectors/getFormError'
import plain from './structure/plain'

export default createGetFormError(plain)
