// @flow
import createReduxForm from './createReduxForm'
import plain from './structure/plain'

export default createReduxForm(plain)
