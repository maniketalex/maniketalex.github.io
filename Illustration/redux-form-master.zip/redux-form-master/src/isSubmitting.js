// @flow
import createIsSubmitting from './selectors/isSubmitting'
import plain from './structure/plain'

export default createIsSubmitting(plain)
