// @flow
import createFormValues from './createFormValues'
import plain from './structure/plain'

export default createFormValues(plain)
