// @flow
import createHasSubmitSucceeded from './selectors/hasSubmitSucceeded'
import plain from './structure/plain'

export default createHasSubmitSucceeded(plain)
