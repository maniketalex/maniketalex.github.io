// @flow
import createIsInvalid from './selectors/isInvalid'
import plain from './structure/plain'

export default createIsInvalid(plain)
