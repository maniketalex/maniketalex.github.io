// @flow
import type { Node } from 'react'

export type Props = {
  children: (form: { name: string }) => Node
}
