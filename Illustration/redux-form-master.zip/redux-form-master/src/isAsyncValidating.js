// @flow
import createIsAsyncValidating from './selectors/isAsyncValidating'
import plain from './structure/plain'

export default createIsAsyncValidating(plain)
