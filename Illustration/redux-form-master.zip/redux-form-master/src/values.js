// @flow
import createValues from './createValues'
import plain from './structure/plain'

export default createValues(plain)
