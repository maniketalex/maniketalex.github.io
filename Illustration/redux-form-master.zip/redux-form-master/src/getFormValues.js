// @flow
import createGetFormValues from './selectors/getFormValues'
import plain from './structure/plain'

export default createGetFormValues(plain)
