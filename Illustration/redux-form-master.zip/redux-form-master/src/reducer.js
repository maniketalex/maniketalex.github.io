// @flow
import createReducer from './createReducer'
import plain from './structure/plain'

export default createReducer(plain)
