// @flow
import createGetFormSyncErrors from './selectors/getFormSyncErrors'
import plain from './structure/plain'

export default createGetFormSyncErrors(plain)
