// @flow
import createFields from './createFields'
import plain from './structure/plain'

export default createFields(plain)
