// @flow
import createGetFormSyncWarnings from './selectors/getFormSyncWarnings'
import plain from './structure/plain'

export default createGetFormSyncWarnings(plain)
