<!--
Read the [contributing guidelines](https://github.com/redux-form/redux-form/blob/master/CONTRIBUTING.md).

We are excited about pull requests, but please try to limit the scope, provide a general description of the changes, and remember, it's up to you to convince us to land it.

If this fixes an open issue, link to it in the following way: `Closes #GH-123`.

New features and bug fixes should come with tests.

P.S. have you seen our support and contributing docs?
https://github.com/redux-form/redux-form/blob/master/CONTRIBUTING.md
-->
